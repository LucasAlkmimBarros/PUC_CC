README

Bom dia Theldo! Semana passada acabei me atrasando nos projetos e nao consegui entregar o guia 06. Portanto estou entregando ele agora junto com o guia 07.
Desde ja, agradeco!
