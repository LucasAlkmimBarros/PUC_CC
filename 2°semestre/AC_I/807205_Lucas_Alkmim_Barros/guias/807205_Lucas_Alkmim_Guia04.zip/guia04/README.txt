README

Bom dia Theldo! Nao estava em casa no fim de semana, e, por isso, nao tinha a ferramenta iverilog disponivel(q2, q3, q4, q5), ja que estava em outro computador. Usei um compilador online para verificar meus codigos, e coloquei eles no "Guia04.txt'. Desde ja, agradeco!!
